<form action="" method="get" name="hasil">
<input type="text" size="3" name="x"/>
<select name="aksi"><option value="tambah">+</option>
<option value="kurang">-</option>
<option value="kali" selected>x</option>
<option value="bagi">:</option></option>
</select>
<input type="text" size="3" name="y"/>
<input type="submit" value="="/></form>

<p><textarea><?php 
$x=$_GET['x'];
$y=$_GET['y'];
$aksi=$_GET['aksi'];

if (isset($aksi)) {
$tambah=$x+$y;
$kurang=$x-$y;
$kali=$x*$y;
$bagi=$x/$y; }
if ($aksi==tambah) echo "hasil $x + $y = $tambah";
if ($aksi==kurang) echo "hasil $x - $y = $kurang";
if ($aksi==kali) echo "hasil $x x $y = $kali";
if ($aksi==bagi) echo "hasil $x : $y = $bagi"; ?></textarea></p>